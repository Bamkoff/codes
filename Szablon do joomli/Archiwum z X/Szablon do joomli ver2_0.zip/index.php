<?php
// dostep bezposredni jest niedozwolony
defined( '_JEXEC' ) or die( 'Restricted access' );?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="PL-pl" xmlns="http://www.w3.org/1999/xhtml">
<!-------------------------------------------------------------------------------------------------------------------------------->  
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="Grafika, Studio, Studio Graficzne, Grafiki, Zdjęcia">
	<meta name="description" content="Witryna studia graficznego">
    <link href="templates/Szablon_galerii_ver2_0/css/bootstrap.min.css" rel="stylesheet">
	<link href="templates/Szablon_galerii_ver2_0/css/style.css" rel="stylesheet">
  </head>
<!--Menu--------------------------------------------------------------------------------------------------------------------------------->  
  <body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
	 <div class="container">
		<div class="cotainer-fluid">
			<div class="navbar-header">
				<button class="btn navbar-btn"><a href="http://barfabi.cba.pl/studio_graficzne/#"><span class="glyphicon glyphicon-home"></span></a></button>
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
		</div>
	 <div class="collapse navbar-collapse float-right" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
		<li class="pad-right"><button class="btn btn-primary navbar-btn"><a href="http://barfabi.cba.pl/studio_graficzne/index.php/8-menu-glowne/3-o-firmie"><span class="text-white" >O firmie</span></a></button></li>
        <li class="pad-right"><button class="btn btn-primary navbar-btn"><a href="http://barfabi.cba.pl/studio_graficzne/index.php/8-menu-glowne/4-zespol"><span class="text-white" >Zespół</span></a></button></li>
        <li class="pad-right"><button class="btn btn-primary navbar-btn"><a href="http://barfabi.cba.pl/studio_graficzne/index.php/8-menu-glowne/5-portfolio"><span class="text-white" >Portfolio</span></a></button></li>
		<li class="pad-right"><button class="btn btn-primary navbar-btn"><a href="http://barfabi.cba.pl/studio_graficzne/index.php/8-menu-glowne/6-kontakt"><span class="text-white" >Kontakt</span></a></button></li>
		<li><button class="btn btn-primary navbar-btn"><a href="http://barfabi.cba.pl/studio_graficzne/index.php/8-menu-glowne/7-aktualnosci"><span class="text-white" >Aktualności</span></a></button></li>
      </ul>
	 </div>
	 </div>
	</nav
<!--Karuzela------------------------------------------------------------------------------------------------------------------------------------------------------->
	<div class="back-grey pad-top">
		<div class="container-fixed">
			<div class="row">
				<div class="col-xm-0 col-sm-0 col-md-1 col-lg-2">
			
				</div>
				<div id="carousel-example-generic2" class="carousel slide col-xm-12 col-sm-12 col-md-10 col-lg-8">
		
					<ol class="carousel-indicators">
						<li data-target="#carousel-example-generic2" data-slide-to="0" class="active"></li>
						<li data-target="#carousel-example-generic2" data-slide-to="1"></li>
						<li data-target="#carousel-example-generic2" data-slide-to="2"></li>
					</ol>
		
					<div class="carousel-inner">
						<div class="item active">
							<jdoc:include type="modules" name="zdjecie1" style="xhtml" />
						</div>
		
						<div class="item">
							<jdoc:include type="modules" name="zdjecie2" style="xhtml" />
						</div>
		
						<div class="item">
							<jdoc:include type="modules" name="zdjecie3" style="xhtml" />
						</div>
					</div>
					
					<a class="left carousel-control" href="#carousel-example-generic2" data-slide="prev">
						<span class="icon-prev"></span>
					</a>
				
					<a class="right carousel-control" href="#carousel-example-generic2" data-slide="next">
						<span class="icon-next"></span>
					</a>
				
				</div>
				<div class="col-xm-0 col-sm-0 col-md-1 col-lg-2">
			
				</div>
			</div>
		</div>
	</div>
<!--Treść----------------------------------------------------------------------------------------------------------------------------------------------->	
	<div class="container-fluid">
		<div class="row pad-top">	
			<div class="col-xm-12 col-sm-12 col-md-8 col-lg-8 pad-top">
				<jdoc:include type="component" />
			</div>	
			<div class="col-xm-6 col-md-2 col-sm-6 col-lg-2">
				<div class="pad-top">
					<jdoc:include type="modules" name="srodek-prawo1" style="xhtml" />
				</div>
				<div class="pad-top">
					<jdoc:include type="modules" name="srodek-prawo2" style="xhtml" />
				</div>
				<div class="pad-top">
					<jdoc:include type="modules" name="srodek-prawo3" style="xhtml" />
				</div>
			</div>
		</div>
	</div>
<!-Stopka------------------------------------------------------------------------------------------------------------------------------------------------------->	
	<div class="container">
		<div class="row pad-top">
			<div class="col-xm-12 col-sm-12 col-md-4 col-lg-4 pad-top">
				<jdoc:include type="modules" name="dol-lewo" style="xhtml" />
			</div>	
			<div class="col-xm-12 col-sm-6 col-md-4 col-lg-4 pad-top">
				<jdoc:include type="modules" name="dol-srodek" style="xhtml" />
			</div>	
			<div class="col-xm-12 col-sm-6 col-md-4 col-lg-4 pad-top">
				<jdoc:include type="modules" name="dol-prawo" style="xhtml" />
			</div>	
		</div>
	</div>
<!----------------------------------------------------------------------------------------------------------------------------------->	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="templates/Szablon_galerii_ver2_0/js/bootstrap.min.js"></script>
  </body>
</html>